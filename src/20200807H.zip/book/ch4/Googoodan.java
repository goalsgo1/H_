package book.ch4;

public class Googoodan {

	public static void main(String[] args) {

		for (int i = 2; i < 10; i++) { //2단 부터 9단까지
			for (int j = 1; j < 10; j++) { //i단의 9곱하기 까지
				System.out.println(i + "*" + j + "=" + i * j);

			}

		}
	}

}
