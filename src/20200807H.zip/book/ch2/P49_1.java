package book.ch2;

public class P49_1 {

	public static void main(String[] args) {
		int i = 10;
		P49_1 p49_1 = new P49_1();
		p49_1.methodB(i);
	}
	
	void methodA() {
		
	}
	void methodB(int b) {
		System.out.println(b);
	}

}
