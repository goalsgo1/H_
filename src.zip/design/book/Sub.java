package design.book;

import javax.swing.JDialog;

public class Sub {
//	mainjava sb = null;
//	
//	public subjava(mainjava sb) {
//		this.sb = sb;
//	}
	
	
	public static void main(String[] args) {
		
	}

}
