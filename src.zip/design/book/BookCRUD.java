package design.book;

import javax.swing.JDialog;

public class BookCRUD extends JDialog {
	public void initDisplay() {
		//this.setTitle("입력|수정|상세보기");//여기서 의미가 없다 밖에서 처리한다.(테스트용으로 잠깐 적음)
		//this.setSize(500, 400); //여기서 의미가 없다 밖에서 처리한다.(테스트용으로 잠깐 적음)
		//this.setVisible(false); //선택되면 열리는창 // 열려있으면 안되니까 false
	}
//	public static void main(String args[]) { //이 화면이 앞에있는 화면에서 선택해서 열렷으면 좋겠다................
//		new BookCRUD().initDisplay();
//	}
}
