package design.book;

import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.beans.EventHandler; //이벤트 헨틀러가 왜 생겼을까

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JToolBar;

//public class BookManager extends JFrame implements ActionListener {
	public class BookManager extends JFrame{
	// 메뉴에 관련된 부분
//	public class jff() {
//		
//	}

		
	JMenuBar jmb = new JMenuBar();
	
	JMenu jm_edit = new JMenu("Edit");
	
	JMenuItem jmi_ins = new JMenuItem("입력");
	JMenuItem jmi_upd = new JMenuItem("수정");
	JMenuItem jmi_det = new JMenuItem("상세보기");
	JSeparator jsl = new JSeparator();
	JMenuItem jmi_exit = new JMenuItem("나가기");
	
	//생성자는 디폴트 생성자를 제외하고는 무조건 개발자가 추가로 작성한다.
	
	//BookManagerEventHandler handler = new BookManagerEventHandler(this);//어디에서나 사용할수 있게 //this 가오는 이유 //여기까지 생각해낸 사람이 잘하는 사람 길을 아는사람
	BookManagerEventHandler handler = new BookManagerEventHandler(this);
	//이벤트 처리를 밖으로 빼놨기 때문에 입력을체크 해야한다 입력체크를 이벤트 헨들러 화면으로 보내야하기 때문에 ....... this
	BookCRUD bookCRUD = new BookCRUD();
	
	

	public BookManager() {

	}

	public void initDisplay() {
		
		//insert here //인스턴스화
		//EventHandler handler = new EventHandler("입력","수정","상세보기","나가기"); -----------
		//이벤트 소스와 이벤트 처리 핸들러 클래스를 매칭하기
		//jmi_ins.addActionListener(this); //this는 BookManager 이 클래스 안에 actionperformed가 있어야 한다.
		jmi_ins.addActionListener(handler);
		jmi_upd.addActionListener(handler);
		jmi_det.addActionListener(handler);
		jmi_exit.addActionListener(handler);
		jm_edit.add(jmi_ins);
		jm_edit.add(jmi_upd);
		jm_edit.add(jmi_det);
		jm_edit.add(jsl);
		jm_edit.add(jmi_exit);
		jmb.add(jm_edit); //jmb = 메뉴바 //
		this.setJMenuBar(jmb); 
		this.setTitle("도서관리 시스템 Ver1.0");
		this.setSize(700, 450);
		this.setVisible(true);

	}

	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);  //창화면의 상단 파란색부분 (화면크기 설정 포함되어있음)
		BookManager bm = new BookManager();  //자신 클래스를 인스턴스화
		bm.initDisplay(); //화면 켜주는 ..
//		AKK akk = new AKK();
	}
	//어노테이션의 이름은 오버라이드 이다. :부모가 선언한 메소드를 제정의 하는것이다.
//	@Override
//	public void actionPerformed(ActionEvent arg0) {//자바에서 실행하는 콜백 메소드 (내가 건들면 안된다.)
//		
//	}

}
