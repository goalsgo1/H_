package design.book;

public class AKK {
	public static void main(String[] args) {
		System.out.println("AKK부름");
	}
	
}
