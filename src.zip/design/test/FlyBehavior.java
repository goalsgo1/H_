package design.test;
/*
 * 인터페이스는 메소드 선언만 할수 있다. - 바디가 없다? 이런느낌  if,while,print도 못한다 
 * 아직 결정할수 없다. 왜냐하면 클래스가 정해지지 않았으니까........
 */
public interface FlyBehavior{
	public void fly();
	public int methodA();
	public int methodB(int i); 
	//위 세개의 공통점:바디가 없다...

}
