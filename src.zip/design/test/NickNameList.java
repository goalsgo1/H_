package design.test;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
//디폴트 생성자는 생략이 가능하다 -왜냐하면 파라미터가 없으니까 JVM이 대신 해줄 수 있어서...
public class NickNameList extends JFrame implements MouseListener {
	static NickNameList nnList = null;
	String cols[] = {"대화명", "성별"};
	String data[][] = {
			{"test","남"}
			,{"apple","여"}
			,{"tomato","여"}
	};
	DefaultTableModel dtm = new DefaultTableModel(data,cols);
	//테이블 생성시 데이터셋에 대한 헤더 초기화 부분이 필요하다. => dtm이 필요하다.
	JTable jtb = new JTable(dtm);
	JScrollPane jsp = new JScrollPane(jtb
			,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
			,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	

	public void initDisplay() {
//		this.setTitle("단톡명단");
//		this.setSize(450, 500);
//		this.setVisible(true);
		
		jtb.addMouseListener(this);
		
		nnList.add("Center",jsp);
		nnList.setTitle("단톡명단");
		nnList.setSize(450, 500);
		nnList.setVisible(true);
	}
	
	public static void main(String[] args) {
		//new NickNameList().initDisplay();
		nnList = new NickNameList();
		nnList.initDisplay();
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getClickCount()==2) {
			System.out.println("더블 클릭 한거야");
			int index[] = jtb.getSelectedRows();
			if(index.length == 0) {
				JOptionPane.showMessageDialog(this, "조회할 데이터를 선택하시오");
				return;
			}
			else if(index.length > 3) {
				JOptionPane.showMessageDialog(this, "데이터를 한 건만 선택하시오");
				return;
			}
			else {
				String nickName =(String)dtm.getValueAt(index[0], 0);
				System.out.println("nickName :" + nickName);
				//지변 위치...
				NickNameDetail nnd = new NickNameDetail(); //인스턴스화 되면 메소드 호출 가능 //initdisplay 호출
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
