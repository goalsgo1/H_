package design.test;

public class DuckSimulation {
//선언부와 생성부의 이름이 다르면 다형성(폴리모피즘 으로 검색)을 기대할 수 있다.
//다형성이란 같은 이름의 메소드를 호출했는데 결과가 서로 다르다
//다형성의 전제조건은 선언부 타입과 생성부 타입이 무조건 다를때 기대할 수 있다.
	//재사용성을 높이는 코딩 방법으로 중요함.
	public static void main(String[] args) {
		//추상클래스도 구현체 클래스가 있어야만 할것이다.
		//MallardDuck myDuck = new MallardDuck();
		Duck myDuck = new MallardDuck();
		myDuck.methodA(); //flyBehavior.fly
		Duck herDuck = new WoodDuck(); //WoodDuck
		herDuck.methodA();
		herDuck.swimming();
		Duck himDuck = new RubberDuck();
		himDuck.methodA();
		himDuck.swimming();
	}

}
