package design.test;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
/* 나는 인스턴스화 할수 있다. (A a = new A(); , A a = methodA();)
 * 인스턴스 변수를 활용하여 변수사용[전역변수에 대한 이야기] 및 메소드 호출[파라미터, 리턴타입]할 수 있다.
 * UI부분과 업무처리 부분을 나눈다
 * 자세히 말하면 화면과 로직을 분리해야 한다.
 * 화면과 이벤트 처리 -약 50%(시작이 소통이고 업무시작이기 때문에 - 리턴타입과 파라미터)
 * 업무내용 - 약 20%
 * DB연동및 업무처리 - 약 30%
 */
import javax.swing.table.DefaultTableModel;

public class Exam1 extends JFrame implements ActionListener { // event 처리?
	// 선언부 - 주의 선언부에서 메소드 호출이나 갑에 대한 재정의 불가함.
	// 테이블 추가하기
	JTable jtb_list = null; // 테이블 양식 만들기
	JScrollPane jsp_list = null; // 스크롤바를 생성하기- JTable
	DefaultTableModel dtm_list = null; // 테이블 안에 들어갈 데이터 설정하기
	String cols[] = { "성명", "자바", "오라클", "HTML", "총점", "평균", "석차" };
	String data[][] = null; // 2차 배열이 필요하다. X축 Y축 다 필요하다. //학생수가 미정이여서 null이다.

	JPanel jp_north = new JPanel();
	JTextField jtf_inwon = new JTextField(); // 화면이 열리자 마자 보여져야 하니까 한번에 생성
	JButton jbtn_create = new JButton("생성");
	// 남쪽에 붙일 속지 생성하기
	JPanel jp_south = new JPanel();
	// 남쪽 속지에 들어갈 버튼 두개
	JButton jbtn_account = new JButton("처리");
	JButton jbtn_exit = new JButton("종료");
	int inwon = 0;
	// 화면을 갱신할때는 Container를 활용하자.
	Container cont = this.getContentPane();// 맨 밑에 깔려있는 속지.
	// 생성자

	public Exam1() {

	}

	// 화면처리부
	public void initDisplay() {
		jbtn_create.addActionListener(this); // 이 줄이 없으면 actionPerformed가 호출이 안된다.
		jbtn_exit.addActionListener(this); // 이 줄이 없으면 actionPerformed가 호출이 안된다. 버튼감지이벤트감지되었을때 actionPerformed 호출
		
		// 속지의 레이아웃을 BorderLayout으로 해야 한다. center에 jtf_inwon을 east jbtn_create를 담기.
		jp_north.setLayout(new BorderLayout());
		jp_north.add("Center", jtf_inwon);
		jp_north.add("East", jbtn_create);
		// 남쪽 속지 레이아웃 flowlayout으로 설정하기- 파라미터로 정렬 하기 가능함.
		jp_south.setLayout(new FlowLayout(FlowLayout.RIGHT));
		jp_south.add(jbtn_account);
		jp_south.add(jbtn_exit);
		this.add("North", jp_north);
		this.add("South", jp_south);

		this.setSize(500, 400);
		this.setVisible(true);
	}
	//성적 처리 메소드 구현 - 업무처리 -알고리즘 공부해라 ... 당분간은 공부x 때가 아니다.
	public void account() {
		System.out.println("성적처리 메소드 호출 성공");
	}
	// 메인메소드 = 메인스레드 이다.라이프사이클 관리 start() service() destroy() //시작하고 활동하고 죽는것
	//시작하고 죽는건 자바가상머신이 다 하니까 service()만 잘하면 된다
	public static void main(String[] args) {
		// 생각해볼 문제: initDisplay()를 메인메소드에서 호출하는 것과 생성자에서 호출하는
		// 것 사이에는 어떤 차이가 있는 걸까?
		Exam1 e1 = new Exam1();
		e1.initDisplay();
	}

	// 두 클래스가 서로 상속관계 이거나 인터페이스를 구현하는 구현체 클래스 이라면 // *구현체 클래스*
	// 반드시 재정의 해야 한다. -오버라이드
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_account) {
			//사용자가 입력한 정보를 수
			account(); //메소드 호출
		}
		
		else if(obj == jbtn_exit) {//주소번지가 같니?
			System.exit(0);//자바가상머신과 어플사이에 연결고리를 끊는다.-스레드를 반납,메모리 회수,다시 사용불가
			
		}
		// JButton obj = (JButton)e.getSource(); //강제형전환
		if (obj == jbtn_create) { // 너 생성버튼 누른거야?
			System.out.println("생성버튼 호출성공"); // 생성버튼을 눌렀을때 inwon수를 가져온다. //inwon은
			try {
				inwon = Integer.parseInt(jtf_inwon.getText());
			} catch (NumberFormatException e2) {
				JOptionPane.showMessageDialog(this, "숫자만 입력하세요");
				jtf_inwon.setText("");
				return; // actionPerformed를 빠져나감
			}
			// 여기
			jtf_inwon.setEnabled(false);
			jbtn_create.setEnabled(false);
			dtm_list = new DefaultTableModel(data,cols); //cols.length는{ "성명", "자바", "오라클", "HTML", "총점", "평균", "석차" };이것의 갯수이다.
			jtb_list = new JTable(dtm_list); //디폴트 생성자.
			jsp_list = new JScrollPane(jtb_list
					,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
					,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); //테이블하고 연결 //테이블하고는 데이터도 연결 
			cont.add("Center",jsp_list);
			cont.revalidate();
			this.setLocation(100,100);
			this.pack();
		}
		
	}
//////////////////////////////////////////////////////////////////// 111번줄 /////////////////////// 
}
