package design.test;

public class FlyNoWay implements FlyBehavior{

	

	@Override
	public void fly() {
		System.out.println("나는 날지 못합니다.");
	}

	@Override
	public int methodA() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int methodB(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

}
