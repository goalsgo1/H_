package game.baseballL3;

public class BaseBallGameLogic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
