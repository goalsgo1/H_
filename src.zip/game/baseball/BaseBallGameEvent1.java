package game.baseball;

import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class BaseBallGameEvent1  {

	JFrame jf = new JFrame(); //
	String imgPath = "C:\\workspace_java\\dev.java\\src\\game\\baseball\\";
	Image img = jf.getToolkit().getImage(imgPath+"o_1bf8ua8rh1inv107u1f151fj01raoa2.jpg");

	JPanel jp_center = new JPanel();
	JTextField jtf_user = new JTextField();
	
	JMenuItem jmi_new = new JMenuItem("새게임");

	
	JMenu jm_game = new JMenu("게임");
	
	JPanel jp_east = new JPanel();
	JButton jbtn_new = new JButton("새게임");
	
	JScrollPane jsp_display = null;
	JTextArea jta_display = null;

	public void initDisplay() {
		//jtf_user.addActionListener(this);
		jf.setTitle("야구 숫자 게임 ver1.0");
		jf.setSize(500, 400);
		jf.setVisible(true);
		
		jta_display = new JTextArea() {
			public void paint(Graphics g) {
				g.drawImage(img,0,0,null);
				Point p= jsp_display.getViewport().getViewPosition();
				g.drawImage(img, p.x, p.y, null);
				paintComponent(g);
			}
		};
		jsp_display = new JScrollPane(jta_display);
		
		jm_game.add(jmi_new);
		
		jp_east.add((jbtn_new));
		//jbtn_new.addActionListener(this);



	}
	
	
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);  //창화면의 상단 파란색부분 (화면크기 설정 포함되어있음)

		BaseBallGameEvent1 bbge = new BaseBallGameEvent1();
		bbge.initDisplay();
	}


	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
