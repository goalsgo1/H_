
package book.ch2;

import javax.swing.JOptionPane;

public class Addition3 {

	public static void main(String[] args) {
		int x, y, z, result;
		String xVal, yVal, zVal;
		xVal = JOptionPane.showInputDialog("첫번째 숫자를 입력하시오");
		yVal = JOptionPane.showInputDialog("두번째 숫자를 입력하시오");
		zVal = JOptionPane.showInputDialog("세번째 숫자를 입력하시오");
		x = Integer.parseInt(xVal);
		y = Integer.parseInt(yVal);
		z = Integer.parseInt(zVal);
		result = x*y*z;
		System.out.println(result);
		//
		JOptionPane.showMessageDialog(null, "The result in" + result, "세 숫자의 곱은" , JOptionPane.INFORMATION_MESSAGE);
		//�ڹ� ���� �ӽŰ��� ������� �������.
		System.exit(0);
	}////////////////////////////end of main

}
