package book.ch4;

public class SwitchTest2 {
	String msg;

	public void methodA() {
		int i = 0;
		boolean is0k = false;
		while (!is0k) {
			String msg = "오늘 스터디 할까?";
			switch (i) {
			case 0: {
				String msg1 = "";
			}
				break;
			default:
				break;
			}
		}
	}

	public static void main(String[] args) {
		int j = 0;
	//	for (int i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) {
		}	
	System.out.print(j);
	}
}
