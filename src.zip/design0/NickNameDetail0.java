package design0;

import javax.swing.JButton; //버튼
import javax.swing.JDialog; //화면 그리기
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane; //테두리안에 선그릴때 사용
import javax.swing.JTextField;

import design.test.NickNameDetail;

public class NickNameDetail0  extends JDialog { //JDialog화면 그리기
	
	JPanel jp_south = new JPanel();
	JScrollPane jspLine = new JScrollPane();//테두리 안에 선그리기
	JButton jbtn_close = new JButton("닫기");
	
	JPanel jp_center = new JPanel();
	JLabel jlb_gender = new JLabel("성별");
	
	//JTextField jtf_gender = new JTextField();
	

	
	public void initDisplay() {
		
		this.add("North", jp_south);
		jlb_gender.setBounds(20, 20, 50, 20);
		//jtf_gender.setBounds(120, 20, 100, 20);
		jp_center.add(jlb_gender);
		//jp_center.add(jtf_gender);
		
		
		jp_south.add(jbtn_close); //밑에 공간에 닫기 버튼 
		this.setTitle("상세보기"); //화면 이름
		this.add("Center",jspLine); //테두리 안에 선그리기
		this.add("South", jp_south); //밑에 공간..
		this.setSize(300, 400);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		NickNameDetail0 nnDtail = new NickNameDetail0();
		nnDtail.initDisplay();
	}

}
