package design.book;

import javax.swing.JButton;
//import javax.swing.JDalog;
import javax.swing.JFrame;


public class Main extends JFrame{
	
//	subjava sb = new subjava(this);
//	 
//	
//	public static void main(String[] args) {
//		JButton jbtn = new JButton("등록");
//	}
	
	
//	subjava sbj = new subjava();
//	public void ab() {
//		System.out.print("등록");
//	}
	Main m = null;
	public void Sub(Main m) {
		this.m = m;
		this.add("North",m.getButton());
		this.setTitle("Sub화면입니다.");
		this.setSize(300, 200);
		this.setVisible(true);
	}
	
//public class Main extends JFrame {
//	JButton jbtn_add = new JButton("등록");
//	Main m = null;
//	public Main getInstance() {
//		if(m!=null) {
//			m = new Main();
//		}
//		return m;
//	}
//}
	
	
	JButton jbtn_add = new JButton("등록");
	
	public JButton getButton() {
		return jbtn_add;
	}
	
	public static void main(String[] args) {
		Main m = new Main();
		Sub sub = new Sub();
	}
}
