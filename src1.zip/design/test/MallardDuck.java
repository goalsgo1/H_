package design.test;
/*
 * FlyBehavior는 인터페이스 임.
 * 메소드 선언만 되어있고 바디가 없는 상태임.
 * 반드시 구현체 클래스가 있어야 활용할 수 있다.
 * 이 세상에 나는 동물, 사물들이 많이 있다.
 * 사물이 갖는 공통분모를 찾기 위해 인터페이스를 설계한다.
 * 단독으로는 인스턴스화 할 수 없다. 추상메소드를 가지고 있으니깐. -결정된 메소드가 아님. -쓸수 없다
 * 
 */
//public class MallardDuck implements FlyBehavior { //implements FlyBehavior은 불필요하다.

//}
public class MallardDuck extends Duck{ //implements FlyBehavior은 불필요하다.
	//FlyBehavior flyBehavior = null; 아빠꺼니까 주석처리 해도 에러가 안뜬다.
	public MallardDuck() { //생성자.
//		flyBehavior = new FlyBehavior(); //불가능
		flyBehavior = new FlyWithWings(); //가능 //DuckSimulation 클래스에서 실행하면 "나는 날고 있어요"
		//flyBehavior = new FlyNoWay(); //가능 //DuckSimulation 클래스에서 실행하면 "나는 날지 못합니다"
		//flyBehavior.fly(); 필요 없어짐.
		quackBehavior = new Quack(); 
	}
	@Override //재정의
	public void swimming() {
		System.out.println("나는 물위에 뜹니다.");
	}
}
