package design.test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class NickNameDetail extends JDialog {
	//static NickNameDetail nnDtail = null;
	JScrollPane jspLine = new JScrollPane(); //테두리 선 그려주기 //분리를 해야 한다. //이 스크롤팬에 
	//현재 중앙에 JScrollpane을 사용한 상태이고 그 이유는 테두리선을 활용
	//그 위에 새로운 속지를 얹ㅇ어서 추가적인 화면 콤포넌트들을 배치할 수 있다.
	//이때 Layout대신 일일이 좌표값을 활용하여 배치해 본다.
	
	JPanel jp_center = new JPanel();
	JLabel jlb_gender = new JLabel("성별");
	JTextField jtf_gender = new JTextField();
	JPanel jp_south = new JPanel();
	JButton jbtn_save = new JButton("저장");
	JButton jbtn_close = new JButton("닫기");
	public NickNameDetail() {
	}
	public void update() {
		System.out.println("수정 메소드 호출 성공");
	}
	public void initDisplay() {
		//JDialog의 디폴트 레이아웃은 BorderLayout임
		//직접 좌표값을 활용하여 배치 할때는 레이아웃이 필요없음.
		jp_center.setLayout(null); //FlowLayout임-null 뭉겐다. - 좌표값
		jlb_gender.setBounds(20, 20, 50, 20);
		jtf_gender.setBounds(120, 20, 100, 20);
		jp_center.add(jlb_gender);
		jp_center.add(jtf_gender);
		jspLine = new JScrollPane(jp_center);
		
		
		this.setLayout(null);
		jbtn_save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ae) {
				update();
			}
		});
		jbtn_close.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ae) {
				System.exit(0);
			}
		});
		jp_south.add(jbtn_close);
		this.setTitle("상세보기");
		this.add("Center",jspLine);  //테두리 선 그리기
		this.add("South", jp_south);
		this.setSize(300, 400);
		this.setVisible(true); //만일 전변으로 인스턴스화를 하였다면 false로 바꿔주세요. 이벤트가 일어나면 그때 true로 바꿔주세요.
	}
	//////////////////////////[[setter | getter]]////////////////////////////
	public void setGender(String gender) {
		jtf_gender.setText(gender);
	}
	
	public void getGender() {//값을 내보내는것
		jtf_gender.getText();
		//메소드를 활용하여 초기화 하기
//		MemberVO mVO = new MemberVO(); mVO.setGender(jtf_gender.get,........
		
		//생성자의 파라미터를 활용하여 초기화 한다.
		//MemberVO mVO = new MemberVO(null,jtf_gender.getText());
	}
	
	
	
	//////////////////////////[[setter | getter]]////////////////////////////
	public static void main(String[] args) {
		NickNameDetail nnDtail = new NickNameDetail();
		nnDtail.initDisplay();
		
	}

}
