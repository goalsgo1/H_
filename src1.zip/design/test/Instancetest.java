package design.test; //인스턴스화 분리

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Instancetest extends JFrame{
	//JFrame jf = new Instancetest(); 	//선언부의 타입과 생성부의 타입이 다를수 있다.(다형성) 크기 => JFrame > Instancetest
	//선언부
	
	JButton jbtn_n = null;
	
	public Instancetest() {
		jbtn_n = new JButton("북쪽");
	}
	//생성자
	public Instancetest(String label) {
		JButton jbtn_s = new JButton(label);
	}
	//화면처리부
	public void initDisplay()  {
		if(jbtn_n!= null)
		this.add("North", jbtn_n);
		this.setSize(400,500);
		this.setVisible(true);
	}
	//메인메소드
	public static void main(String[] args) {
		JFrame jf = new Instancetest("남쪽");//아빠 타입의 변수에 아들타입을 넣었다. 아빠타입의 변수로는 아들 타입에 선언된 메소드를 호출할수 없다.
		Instancetest it = new Instancetest("남쪽");
//		jf.initDisplay(): //아빠타입의 변수로 아들타입에 선언된 메소드를 호출할 수 없다.
		it.initDisplay();
		
	}

}
