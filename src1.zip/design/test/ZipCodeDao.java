package design.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.util.DBConnectionMgr;

public class ZipCodeDao {
	DBConnectionMgr dbMgr   = null;
	Connection con 		    = null;
	PreparedStatement pstmt = null;
	ResultSet rs		    = null;
	public ZipCodeVO[] getZipCodeList(String dong) {
		ZipCodeVO zVOS[] = null; //매번 바뀌는거 지변
		dbMgr = DBConnectionMgr.getInstance();
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT zipcode, address"  );
	    sql.append(" FROM zipcode_t"           );
	    sql.append(" WHERE dong LIKE ?"); //숫자가 들어감
		try{ //예측 불가능한것 그래서 try catch를 써야함
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, dong+"%");
			rs = pstmt.executeQuery(); //소통하는 프로그램이 중요 
			ZipCodeVO zVO =null;
			Vector v = new Vector();
			while (rs.next()) {
				zVO = new ZipCodeVO();
				zVO.setZipcode(rs.getInt("zipcode"));
				zVO.setAddress(rs.getString("address"));
				v.add(zVO);
				
			}
			zVOS = new ZipCodeVO[v.size()];//이배열 안에는 default 값이 
			v.copyInto(zVOS); //벡터에 있는것을 객체 배열에 담을때
		} catch (Exception e) { 
			// TODO: handle exception
		}
		return zVOS; //널포인트인셉션 8번 때문 //8번이 결정이 안되어서// 그래서 7번 파라미터에 String dong를 씀
		
	}
}//잘 되는지 확인을 해야하는데 화면이 없다 화면 클래스를 만든다.
