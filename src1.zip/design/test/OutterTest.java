package design.test;

import design.test.Outter.Inner;

class Outter{
	public void come() {
		System.out.println("");
		
	}
	//내부 클래스라고 한다.
	//반드시 외부클래스를 인스턴스화 해야만 접근이 가능하다.
	//외부클래스의 멤버변수를  사용 가능하다.
	class Inner{
		public void go() {
			System.out.println("go() 호출 성공");
		}
	}
}
public class OutterTest {

	public static void main(String[] args) {
		Outter ot = new Outter();
		ot.come();
		Inner in = ot.new Inner(); //외부 클래스에 접근하기 위해 두번 접근한다.
		in.go();
	}

}
