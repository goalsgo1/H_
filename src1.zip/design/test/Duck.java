package design.test;
//추상 클래스 - 단독으로는 인스턴스화 할 수 없다.
//반드시 구현체 클래스가 있어야 한다.
//그러나 일반 메소드도 가질 수 있다.
//그래서 인터페이스가 더 추상적이다.
public abstract class Duck { //abstract가 오면 추상클래스이다.
	FlyBehavior flyBehavior = null;
	QuackBehavior quackBehavior = null;
	public void methodA() {
		quackBehavior.quack();
	}
	public void methodB() {
		quackBehavior.quack();
	}
	//좌중괄호와 우중괄호가 있는 메소드가 일반메소드임.- 바디가 있다.
	public void display() {
		System.out.println("나는 오리 입니다.");
	}
	//추상메소드임
	//인터페이스에서는 abstract를 생략할수 있지만 - 왜냐함녀 모두 다 추상메소드만 오니깐.
	//그런데 추상클래스는 일반 메소드도 같이 공존하니깐 구분할 수 있어야 겠지?
	public abstract void swimming(); //추상메소드라는걸 표시(abstract)
}
