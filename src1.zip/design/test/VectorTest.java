package design.test;

import java.util.Vector;

public class VectorTest {

	public static void main(String[] args) {
		Vector v = new Vector();
		System.out.println("v.size()==0"+v.size());//v=0일것이다 인스턴스화는 해도 add를 안했기 때문에
		v.add("바나나");
		v.add("수박");
		v.add(1,"체리"); //백터는 배열과 다르게 사이에 끼워넣을수 있다.
		for (Object obj:v) {
			String f = (String)obj;
			System.out.println(f);
		}
	}

}
