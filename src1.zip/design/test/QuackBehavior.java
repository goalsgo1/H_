package design.test;
/*
 * 추상클래스와 인터페이스의 공통점은? - 모두 단독으로는 인스턴스화 불가
 * 반드시 구현체 클래스가 있어야 햠 
 */
public interface QuackBehavior {
	public abstract void quack();//추상메소드
}
