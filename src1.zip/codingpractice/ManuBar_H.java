package codingpractice;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import design0.NickNameDetail0;

public class ManuBar_H extends JDialog{
	JFrame jf = new JFrame();
	JPanel jp_south = new JPanel();
	JScrollPane jspLine = new JScrollPane();
	
	JMenuBar jmb = new JMenuBar();
	
	JMenu jm_input = new JMenu("입력");	// JMenu에 들어갈 하위 메뉴 아이템을 생성하기(New,Open,나가기)

	
	JButton jbtn_close = new JButton("닫기");
	
	public void initDisplay() {
		this.add("North", jp_south);
		jp_south.add(jbtn_close); 
		
		jmb.add(jm_input);

		
		this.setTitle("상세보기"); //화면 이름
		this.add("Center",jspLine); //테두리 안에 선그리기
		this.add("South", jp_south); //밑에 공간..
		this.setSize(300, 400);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		ManuBar_H mb = new ManuBar_H();
		mb.initDisplay();
	}

}
