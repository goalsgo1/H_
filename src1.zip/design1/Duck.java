package design1;
		
public abstract class Duck {
	public void display() {
		System.out.println("나는 오리입니다.");
	}
}
