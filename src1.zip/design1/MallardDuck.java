package design1;

public class MallardDuck {
	
	public void MallarDuck() extends Duck {
		
	}
//	@Override //재정의
//	public void swimming() {
//		System.out.println("나는 물위에 뜹니다.");
//	}
}
