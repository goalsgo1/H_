package design1;

public interface QuackBehavior {
	public abstract void quack();//추상메소드
}
