package design1;

public interface FlyBehavior {
	public void fly();
	public int methodA();
	public int methodB(int i); 
}
