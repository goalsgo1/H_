package game.baseballL3;

public class BaseBallGameEvent {
	
	public static void main(String[] args) {

	}
}
