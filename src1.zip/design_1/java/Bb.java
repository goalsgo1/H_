package design_1.java;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import design.test.Exam1;

public class Bb extends JFrame implements ActionListener {
	// 선언부
	// 테이블 추가하기
	JTable jtb_list = null;
	JScrollPane jsp_list = null;
	DefaultTableModel dtm_list = null;
	String cols[] = { "성명", "자바", "오라클", "HTML", "총점", "평균", "석차" };
	String data[][] = null;
	
	JPanel jp_north = new JPanel();
	JTextField jtf_inwon = new JTextField();

	JButton jbtn_create = new JButton("생성");

	int inwon = 0;
	
	Container cont = this.getContentPane();
	// 생성자

	// 화면 처리부
	public void initDisplay() {
		System.out.println("화면");
		jbtn_create.addActionListener(this); // actionPerformed 호출

		jp_north.setLayout(new BorderLayout());
		jp_north.add("Center", jtf_inwon);
		jp_north.add("East", jbtn_create);

		this.add("North", jp_north);

		this.setSize(500, 400);
		this.setVisible(true);
	}

	// 메인메소드
	public static void main(String[] args) {
		Bb e1 = new Bb();
		e1.initDisplay();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == jbtn_create) {
			try {
				inwon = Integer.parseInt(jtf_inwon.getText());
			} catch (NumberFormatException e2) {
				JOptionPane.showMessageDialog(this, "숫자만 입력하세요");
				jtf_inwon.setText("");
				return; // actionPerformed를 빠져나감 }
			}
			jtf_inwon.setEnabled(false);
			jbtn_create.setEnabled(false);
			dtm_list = new DefaultTableModel(7,7);
			jtb_list = new JTable(dtm_list);
			jsp_list = new JScrollPane(jtb_list
					,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
					,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			cont.add("Center",jsp_list);
			cont.revalidate();
			this.setLocation(100,100);
			this.pack();
		}

	}
}
