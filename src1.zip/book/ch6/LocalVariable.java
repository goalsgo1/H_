package book.ch6;
/*
 * methodA에 선언된 지변을 외부 다른 메소드에서 유지 또는 사용할 수 있나요?
 * 1)static으로 선언한 변수를 사용하는것.
 * 2)전변과 초기화 하기 this.i = 1;
 */
public class LocalVariable {
	int i = 1;
	static int j = 2; // 싱글톤이다.
	// static타입의 변수를 non_static영역에서 사용하는건 가능

	void methodA() {
		int i;
		i = 10;
		this.i = i;
		System.out.println(i);
		System.out.println(j);
	}

	/*
	 * static영역에서는 non_static 사용불가함 
	 * 해결방법은? 
	 * 인스턴스화 하면 사용가능함.
	 */
	public static void main(String[] args) {
		// 메인메소드에서 지역변수 i는 접근 불가함.
		LocalVariable lv = new LocalVariable();
		System.out.println(lv.i); // 1출력됨
		System.out.println(LocalVariable.j); // 1출력됨
		j = 100;
		lv.methodA();
	}

}
