package book.ch6;

public class CompanyTest {

	public static void main(String[] args) {
		Company cp1 = Company.getInstance();
		Company cp2 = Company.getInstance(); //new가 안들어간 이유.. 주소번지가 .. 방이 새로 생기면 주소번지가 달라지기 때문에
		System.out.println(cp1 == cp2); //두개의 주소번지가 같니?
	}

}
