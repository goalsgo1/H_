package book.ch2;

public class P77_2 {

	public static void main(String[] args) {
		int x =3;
		int y = 2;
		if((++x<++y)&&(x>--y)) {
			System.out.println("참");
			System.out.println("X ="+x);
			System.out.println("y= "+y );
			
		}
		else
		{
			System.out.println("거짓");
			System.out.println("X ="+x);
			System.out.println("y= "+y );
		}
	}

}
/*
 * &이게 하나만 있을때
 * 앞에있는게 거짓이어도
 * 앞에서 계산한 x y값으로 
 * 거짓인데도 뒤에것까지 계산하여
 * x y 값을 나타낸다
 * 
 * &&이게 두개일땐 
 * 앞에있는게 거짓이면
 * 앞에서 계산한 x y 값을 
 * 뒤에것 계산하지 않고
 * 앞의 값을 바로 나타낸다.
 * 
 */
