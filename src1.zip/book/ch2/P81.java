package book.ch2;

public class P81 {

	public static void main(String[] args) {
		String account = (45<47) ? "��":"����";
		System.out.print(account);
	}

}
