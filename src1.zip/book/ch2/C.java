package book.ch2;

import javax.swing.JOptionPane;

public class C {

	public static void main(String[] args) {
		String s = JOptionPane.showInputDialog("첫번째 숫자를 입력");
		System.out.println("첫번째 숫자" + s); //s는 string
		String s2 = JOptionPane.showInputDialog("두번째 숫자를 입력");
		System.out.println("두번째 숫자" + s2); //s2는 string
		
//		System.out.println("s"+"s2");  // 이줄은 ss2
		int firstnumber = Integer.parseInt(s); //string s를 int firstnumber에 넣기 (string ->int)
		int secondnumber = Integer.parseInt(s2);
		int a = firstnumber + secondnumber;
		System.out.print("첫번째 숫자 + 두번째 숫자 = " + a);
		
	}

}
