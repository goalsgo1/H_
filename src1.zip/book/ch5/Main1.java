package book.ch5;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Main1 extends JFrame implements ActionListener {
	// 선언부 - 전역변수
	JButton jbtn_south = null;
	JButton jbtn_east = null;
	JButton jbtn_north = null;
	JButton jbtn_center = null;
	JButton jbtn_west = null;
	
	Container cont = this.getContentPane();
	// 남쪽 버튼에 대신 들어갈 JtextField를 선언하기
	// JTextField jtf = new JtextField(); //new는 이벤트가 일어났을 때 할 생각임
	JTextField jtf = null;

	// 생성자 - 리턴타입이 없어야 생성자 이다 파라미터는 여러개 가질수 있다 메소드오보로딩의 규칙을 준수한다 하는역할은 전역변수의 초기화를
	// 담당한다.
	public Main1() {// 디폴트 생성자 //생성자의 역할:전역변수의 초기화를 한다.
		jbtn_south = new JButton("남쪽 (버튼)"); // 버튼 만들기.
		jbtn_east = new JButton("동쪽 (버튼)"); // 버튼 만들기.
		jbtn_north = new JButton("북쪽 (버튼)"); // 버튼 만들기.
		jbtn_center = new JButton("중앙 (버튼)"); // 버튼 만들기.
		jbtn_west= new JButton("서쪽 (버튼)"); // 버튼 만들기.
		
		
		
		initdisplay(); // 내 안에 있는 메소드는 인스턴스화 없이도 호출할 수 있다.

	}

	// 화면처리부 -
	public void initdisplay() {
		jbtn_south.addActionListener(this);
		jbtn_east.addActionListener(this);
//		jbtn_north.addActionListener(this);
//		jbtn_center.addActionListener(this);
		jbtn_west.addActionListener(this);
		
		
		this.add("South", jbtn_south); // 생성자에서 만든 jbtn_south를 남쪽에 붙이기
		this.add("East", jbtn_east); // 생성자에서 만든 jbtn_south를 남쪽에 붙이기
		this.add("West", jbtn_west); // 생성자에서 만든 jbtn_south를 남쪽에 붙이기
		this.add("Center", jbtn_center); // 생성자에서 만든 jbtn_south를 남쪽에 붙이기
		
		
		this.setSize(500, 400);
		this.setVisible(true);
		// south에 버튼하나 붙이기

	}

	// 메인 메소드 -
	public static void main(String[] args) {// 여기에 인스턴스화를 하면 지역변수의 성격을 갖게 되므로 외부 클래스에서 사용불가.
		// 생성자 호출하기
		new Main1();

	}

	// 콜백메소드 - 콜백메소드는 시스템에서 자동으로 실행된다(감지가 되었을때)
	@Override // 같은 이름의 메소드를 사용할수있다 (Override가 있기 때문에)
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_west) {
			if(jbtn_center != null) {
				cont.remove(jbtn_center);
			}
			if(jbtn_west != null) {
				cont.remove(jbtn_west);
			}
			if(jbtn_north != null) {
				cont.remove(jbtn_north);
			}
			if(jbtn_east != null) {
				cont.remove(jbtn_east);
			}
			if(jtf != null) {
				cont.remove(jtf);
			}
		}
		
		if(obj ==jtf) { //JTextField와 주소번지가 같은지 비교함
			System.out.println("jtf 엔터 이벤트 감지함. ===>" + jtf);
			String msg = jtf.getText();
			if("북쪽".equals(msg)) {
				jbtn_north = new JButton("북쪽 (버튼)");
				cont.add("North",jbtn_north);
				cont.revalidate(); // 화면 갱신
			}else if("동쪽".equals(msg)) {
				jbtn_east = new JButton("동쪽 (버튼)");
				cont.add("East",jbtn_east);
				cont.revalidate(); // 화면 갱신
			}else if("중앙".equals(msg)) {
				jbtn_center = new JButton("중앙 (버튼)");
				cont.add("Center",jbtn_center);
				cont.revalidate(); // 화면 갱신
			}else if("서쪽".equals(msg)) {
				jbtn_west = new JButton("서쪽 (버튼)");
				cont.add("West",jbtn_west);
				cont.revalidate(); // 화면 갱신
			}else {
				JOptionPane.showMessageDialog(this, "동서남북 쪽을 입력해!");
				//jtf.setText("북쪽");
				//return;
			}
		}
		else if (obj == jbtn_south) {
			System.out.println("남쪽 버튼 클릭");
			jbtn_east.setText("메뉴");
			//insert here
			//자바에서는 삭제했다고 해서 즉시 바로 없어지는게 아님
			//일단 Candidate상태로 뺀다.(넌 쓰레기 값임)
			cont.remove(jbtn_south); // 삭제할 화면정보 넣기 //버튼을 지워내는...
			jbtn_south = null;
			System.out.println("남쪽 버튼:" + jbtn_south);
			//위치- 끼워둘 위치
			jtf = new JTextField();
			//보통은 (일반적으로) initDisplay에서 이벤트 핸들러와 연결을 해왔다.
			//그런데 오늘은 이벤트가 발동해야 인스턴스화가 완성된다.
			//따라서 이벤트 처리 메소드인 actionPerformed에서 이벤트가 일어나는 그 지점으로
			//옮겨 주어야 한다.
			jtf.addActionListener(this);          //jtextfield 붙이기   
			cont.add("South",jtf);
			cont.revalidate(); // 화면 갱신
		}
		else if(obj == jbtn_north) {
			System.out.println("북쪽 버튼 클릭");
			jbtn_north.setText("메뉴");
			cont.remove(jbtn_north);
			jbtn_north = null;
			jtf.addActionListener(this);          //jtextfield 붙이기   
			cont.add("North",jtf);
			cont.revalidate(); // 화면 갱신
			
		}
	}

}
/*
 * 1) jtf를 이벤트 핸들러와 매칭해줌 jtf.addActionListener(this); 2)actionPerformed에 jtf이벤트가
 * 감지되었을 때 입력된 문자열 값이 북쪽이면 버튼을 생성하여 화면 North영역에 해당 버튼을 붙임 여기서는 다른 콤포넌트가 없던 자리에
 * 붙이는 거니까 remove는 생략 가능 3)북쪽에 들어갈 버튼을 인스턴스화 한다. 4)이벤트 처리에서 생성한 버튼을 화면에 넣고 화면
 * 갱신해주면 끝.
 * 
 * 현재 선언과 생성을 따로 분리하는 것은 특별한 차이가 없다. 그러나 향후에 화면구현시 또는 이벤트 처리할 때 따로 분리하는 부분이
 * 필요하므로 연습해본다.
 * 
 * 다만 생성자안에서 initDisplay를 호출함에 따라 initDisplay를 먼저 호출하면 해당 버튼을 보지 못할수도 있다.
 */
