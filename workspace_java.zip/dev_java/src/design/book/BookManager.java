package design.book;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

import book.ch8.TimeClient;

//public class BookManager extends JFrame implements ActionListener{
public class BookManager extends JFrame{
	JMenuBar jmb 		= new JMenuBar();
	JMenu    jm_edit 	= new JMenu("Edit");
	JMenuItem jmi_ins   = new JMenuItem("입력");
	JMenuItem jmi_upd	= new JMenuItem("수정");
	JMenuItem jmi_det	= new JMenuItem("상세보기");
	JSeparator js1		= new JSeparator();
	JMenuItem jmi_exit	= new JMenuItem("나가기");
	JLabel    jlb_time =  new JLabel("현재 시간",JLabel.CENTER);
	//생성자는 디폴트 생성자를 제외하고는 무조건 개발자가 추가로 작성한다.
	BookManagerEventHandler handler = new BookManagerEventHandler(this);
	BookCRUD bookCRUD = new BookCRUD();
	public BookManager(){
		
	}
	public void initDisplay() {
		//insert here
		
		//이벤트 소스와 이벤트 처리 핸들러 클래스를 매칭하기
		jmi_ins.addActionListener(handler);//this는 BookManager 이 클래스 안에 actionPerformed가 있어야 한다.
		jmi_upd.addActionListener(handler);//this는 BookManager 이 클래스 안에 actionPerformed가 있어야 한다.
		jm_edit.add(jmi_ins);
		jm_edit.add(jmi_upd);
		jm_edit.add(jmi_det);
		jm_edit.add(js1);
		jm_edit.add(jmi_exit);
		jmb.add(jm_edit);
		TimeClient tc = new TimeClient(jlb_time);
		tc.start();//콜백 메소드인 run()이 자동 호출
		this.add("South",jlb_time);
		this.setJMenuBar(jmb);
		this.setTitle("도서관리 시스템 Ver1.0");
		this.setSize(700, 450);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		BookManager bm = new BookManager();
		bm.initDisplay();
	}
	//어노테이션-오버라이드:부모가 선언한 메소드를 재정의하는것.
	/*
	 * @Override public void actionPerformed(ActionEvent e) {
	 * 
	 * }
	 */

}
