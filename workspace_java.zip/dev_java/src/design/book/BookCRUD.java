package design.book;

import javax.swing.JDialog;

public class BookCRUD extends JDialog {
	public void initDisplay() {
		//this.setTitle("입력|수정|상세보기");
		//this.setSize(500, 400);
		this.setVisible(false);
	}
	/*
	public static void main(String args[]) {
		new BookCRUD().initDisplay();
	}
	*/
}
