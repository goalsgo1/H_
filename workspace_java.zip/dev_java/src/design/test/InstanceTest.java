package design.test;

import javax.swing.JButton;
import javax.swing.JFrame;

public class InstanceTest extends JFrame {
	JButton jbtn_n = null;
	public InstanceTest() {
		jbtn_n = new JButton("북쪽");
	}
	public InstanceTest(String label) {
		JButton jbtn_s = new JButton(label);
	}
	public void initDisplay() {
		if(jbtn_n!=null)
			this.add("North",jbtn_n);
		this.setSize(400, 300);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		//아빠 타입의 변수로는 아들 타입에 선언된 메소드를 호출 할 수 없다.
		JFrame jf = new InstanceTest("남쪽");
		InstanceTest it = new InstanceTest("남쪽");
		it.initDisplay();
	}

}
