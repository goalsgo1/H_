package design.test;
/*
 * 인터페이스는 메소드 선언만 할 수 있다. - 바디가 없다???
 * 아직 결정할 수 없다. 왜냐하면 클래스가 정해지지 않았으니까....
 * 좌중괄호와 우중괄호가 없는 메소드를 추상 메소드라고 함.
 */
public interface FlyBehavior {
	public void fly();
	public int methodA();
	public int methodB(int i);
}
