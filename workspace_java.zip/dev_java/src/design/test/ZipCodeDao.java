package design.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import com.util.DBConnectionMgr;

public class ZipCodeDao {
	DBConnectionMgr dbMgr = null;
	Connection con 			= null;
	PreparedStatement pstmt = null;
	ResultSet rs 			= null;
	public ZipCodeVO[] getZipCodeList(String dong) {
		ZipCodeVO zVOS[] = null;//결정안됨
		dbMgr = DBConnectionMgr.getInstance();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT zipcode, address ");
		sql.append("  FROM zipcode_t        ");
		sql.append(" WHERE dong LIKE ?");
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, dong+"%");
			rs = pstmt.executeQuery();
			ZipCodeVO zVO = null;
			Vector v = new Vector();
			while(rs.next()) {
				zVO = new ZipCodeVO();
				zVO.setZipcode(rs.getInt("zipcode"));
				zVO.setAddress(rs.getString("address"));
				v.add(zVO);
			}
			zVOS = new ZipCodeVO[v.size()];
			v.copyInto(zVOS);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return zVOS;
	}
}
