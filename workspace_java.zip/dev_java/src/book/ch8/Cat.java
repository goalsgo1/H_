package book.ch8;

public class Cat extends Animal {

}
