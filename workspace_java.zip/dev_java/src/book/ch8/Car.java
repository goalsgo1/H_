package book.ch8;

public abstract class Car {
	int speed;
	int wheelNum;
	public Car() {
		System.out.println("Car 디폴트 생성자 입니다.");		
	}
	public abstract void initDisplay();
	public void stop() {
		if(speed>0) speed = 0;
	}
}
