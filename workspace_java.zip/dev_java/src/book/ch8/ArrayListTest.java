package book.ch8;

import java.util.ArrayList;
import java.util.List;

public class ArrayListTest {

	public static void main(String[] args) {
		//Vector멀티스레드 안전-속도는 느리다.- 같이쓴다 - wait
		List list = new ArrayList();//싱글스레드 안전함-빠르다
		Dog d = new Dog();
		list.add(d);
		Cat c = new Cat();
		list.add(c);
		for(int i=0;i<list.size();i++) {
			Object obj = list.get(i);
			if(obj instanceof Dog) {
				System.out.println("개 ~~~");
			}
			if(obj instanceof Cat) {
				System.out.println("고양이 ~~~");				
			}
			System.out.println(obj);
		}
	}

}
