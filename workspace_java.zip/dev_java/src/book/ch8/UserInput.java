package book.ch8;

import java.net.Socket;

import javax.swing.JOptionPane;

public class UserInput {

	public static void main(String[] args) {
		String user = 
			JOptionPane.showInputDialog("아이피주소#포트번호 로 입력하세요");
		System.out.println("사용자가 입력한 값은 "+user);
		String ip = "192.168.0.244";
		int port= 5000;
		try {
			Socket socket = new Socket(ip,port);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
