package book.ch8;

public abstract class Animal {

}
