package book.ch8;

public class Pride extends Car {
	
	public Pride() {
		System.out.println("Pride 디폴트 생성자 입니다.");
	}
	@Override
	public void initDisplay() {
		System.out.println("나는 프라이드 입니다.");
		
	}
	//아빠가 가진 메소드 인지 원형을 어떻게 아는 걸까요
	public int initDisplay(int i) {
		System.out.println("나는 프라이드 입니다.");
		return 0;
	}
	public void speedUp() {
		speed = speed + 1;
	}
}
