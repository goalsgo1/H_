package book.ch8;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class TimeServerThread extends Thread {
	TimeServer2 ts = null;
	ObjectOutputStream oos = null;
	ObjectInputStream ois = null;
	Socket client = null;
	String timeStr = null;
	public TimeServerThread(TimeServer2 ts) {
		this.ts = ts;
		this.client = ts.socket;
		try {
			oos = new ObjectOutputStream(client.getOutputStream());
			ois = new ObjectInputStream(client.getInputStream());
			while(true) {
				System.out.println("읽어온 시간은 ==>"+ts.pushTime());
				oos.writeObject(ts.pushTime());
				try {
					sleep(1000);
				} catch (Exception ie) {
					System.out.println("[ie]"+ie.toString());
					ie.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			System.out.println("[Exception]"+e.toString());
		}		
		/**/
		//timeStr = ts.pushTime();
		try {
			//oos = new ObjectOutputStream(client.getOutputStream());
			//ois = new ObjectInputStream(client.getInputStream());
			/*
			for(TimeServerThread tst:ts.globalList) {//개선된 for문-전체 조회할 때-가진거 다 나와
				oos.writeObject(timeStr);
			}
			//현재 서버에 입장한 클라이언트 스레드 추가하기
			ts.globalList.add(this);
			this.broadCasting(timeStr);
			*/
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}
	//현재 입장해 있는 모든 친구들에게 모두 메시지를 전송하고 싶어요
	public void broadCasting(String msg) {
		for(TimeServerThread tst:ts.globalList) {
			try {
				oos.writeObject(msg);
			} catch (Exception e) {
				e.printStackTrace();//stack영역에 쌓여 있는 에러 메시지 모두 출력해줌.
			}
		}
	}
	//run메소드에는 뭘 써야 하지?
	@Override
	public void run() {
		System.out.println("TimeServerThread run 호출 성공");

	}
}
