package book.ch8;

public class Avante extends Car {

	@Override
	public void initDisplay() {
		System.out.println("나는 아반떼 입니다.");
	}

}
