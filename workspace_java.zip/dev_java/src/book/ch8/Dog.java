package book.ch8;
//Animal에 대한 구상 클래스이다.
public class Dog extends Animal {

}
