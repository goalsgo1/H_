package book.ch3;

public class P81 {

	public static void main(String[] args) {
		String account = (45<47) ? "참":"거짓";
		System.out.println(account);
	}

}
