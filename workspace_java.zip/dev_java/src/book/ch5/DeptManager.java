package book.ch5;

import javax.swing.JButton;
import javax.swing.JFrame;
//오늘 부터는 되도록이면 메인 메소드에 코딩을 하지 않는다.
//한번에 어렵다면 조금씩 부피를 줄여본다.
//생성자는 의존관계를 실제로 표현할 수 있다. - 클래스 쪼개기 연습시 꼭 활용해 볼것.
//static은 사용하지 말것.
//while문 i=i+1; break; for문안에 break;
//반드시 무한루프 방지 코드를 작성할 것.
public class DeptManager extends JFrame {
	int deptno;//10->30
	//BorderLayout -안드로이드 수업
	JButton jbtn_center = new JButton();
	JButton jbtn_north = new JButton("북쪽");
	JButton jbtn_south = new JButton("남쪽");
	JButton jbtn_east = new JButton("동쪽");
	JButton jbtn_west = new JButton("서쪽");
	//역할은 전변에 초기화를 대신 해줌.- 그래서 생략이 가능하다.
	//지변은 초기화를 반드시 해야 됨.
	public DeptManager() {//디폴트 생성자는 생략할 수 있다.
		System.out.println("디폴트 생성자 ");
	}
	public DeptManager(int deptno) {//디폴트 생성자는 생략할 수 있다. 10
		this.deptno = deptno;//10
		this.deptno = 30;//초기화
		System.out.println("디폴트 생성자1 "+this.deptno);
		initDisplay();
	}
	void methodA() {
		System.out.println("methodA에서 "+deptno);		
	}
	//화면 그리기
	public void initDisplay() {
		jbtn_center.setText("중앙");
		this.add("Center",jbtn_center);
		this.add("North",jbtn_north);
		this.add("South",jbtn_south);
		this.add("East",jbtn_east);
		this.add("West",jbtn_west);
		this.setSize(400, 300);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		new DeptManager(10);
	}

}
