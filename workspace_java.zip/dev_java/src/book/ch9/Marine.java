package book.ch9;

public class Marine extends Unit {

	@Override
	void move(int x, int y) {
		// TODO Auto-generated method stub
		
	}
	void stimPack() {}
}
