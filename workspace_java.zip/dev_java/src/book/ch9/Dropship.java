package book.ch9;

public class Dropship extends Unit {

	@Override
	void move(int x, int y) {
		// TODO Auto-generated method stub
		
	}
	//선택한 유닛을 태운다
	void load() {}
	//대상 유닛을 내린다.
	void unload() {}

}
