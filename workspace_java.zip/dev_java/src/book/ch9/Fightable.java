package book.ch9;

public interface Fightable extends Movable, Attackable{

}
