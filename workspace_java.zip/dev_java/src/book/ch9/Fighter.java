package book.ch9;

public class Fighter extends Unit implements Fightable {

	@Override
	public void attack(Unit u) {
		// TODO Auto-generated method stub
		
	}
//오버라이드시에 접근 제한자는 반드시 더 넓은 범위로 처리해야 함.
	@Override
	public void move(int x, int y) {
		// TODO Auto-generated method stub
		
	}

}
