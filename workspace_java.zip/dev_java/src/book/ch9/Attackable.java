package book.ch9;
//상속은 단일 상속만 가능함.
//인터페이스는 다중 구현이 가능함
//단일 상속의 단점을 보완하기 위해서 임.
public interface Attackable {
	void attack(Unit u);
}
