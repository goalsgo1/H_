package book.ch9;

public class Tank extends Unit {

	@Override
	void move(int x, int y) {
		// TODO Auto-generated method stub
		
	}
	void chaneMode() {
		
	}

}
