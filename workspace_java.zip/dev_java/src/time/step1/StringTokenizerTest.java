package time.step1;

import java.util.StringTokenizer;

import javax.swing.JOptionPane;

public class StringTokenizerTest {

	public static void main(String[] args) {
		String user = null;
		user = JOptionPane.showInputDialog("아이피랑 포트랑 입력해줘");
		String ip = "127.0.0.1";
		int port = 0;
		StringTokenizer st = new StringTokenizer(user,"#");
		ip = st.nextToken();
		String imsi = st.nextToken();
		port = Integer.parseInt(imsi);
		System.out.println("사용자가 입력한 ip와 port는 " +ip + ", "+port);

	}

}
