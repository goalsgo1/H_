package time.step1;

import java.awt.Font;
import java.util.StringTokenizer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class MovieApp extends JFrame {
	JLabel jlb_time = null;
	//타입 서버 기동시키기
	TimeServer ts = null;
	TimeClient tc = null;
	public MovieApp() {
		//ts = new TimeServer();
	}
	public void initDisplay() {
		jlb_time =new JLabel("현재시간 출력할 곳",JLabel.CENTER);
		Font f = new Font("돋움체",Font.BOLD,55);
		jlb_time.setFont(f);
		//이 때 주의사항은 반드시 jlb_time이 인스턴스화 되어 있다.
		String 	ip 		= "192.168.0.244";
		int 	port 	= 20000;
		String user = 
		JOptionPane.showInputDialog("아이피주소#포트번호 로 입력하세요");
		StringTokenizer st = new StringTokenizer(user,"#");
		ip = st.nextToken();
		String imsi = st.nextToken();
		port = Integer.parseInt(imsi);
		tc = new TimeClient(jlb_time, ip, port);
		tc.start();
		this.add("North", jlb_time);
		this.setSize(400, 300);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		MovieApp ma = new MovieApp();
		ma.initDisplay();
	}

}
