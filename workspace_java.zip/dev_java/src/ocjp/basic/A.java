package ocjp.basic;

public class A {

	public static void main(String[] args) {
		int a=0, b=0, c =0;
		System.out.println(a);
		System.out.println(b);
		System.out.println(b);
		int is[], is2;
		int[] as, as2;
		is = new int[1];
		is2 = 1;
		
		as = new int[1];
		as2 = new int[1];
	}

}
