package ocjp.basic;

public class Q12 {
	int x = 0;
	 public static void main(String []args) {
		 int x = 5;  //main에서 선언된 지역변수
//		 Q12 p = null;//선언만 되었다. - 이 주소번지를 사용하면 NullPointerException이 발생-Runtime에러라고 함.
		 Q12 p = new Q12();
		 p.doStuff(p);
		 System.out.print(" main x = "+ p.x);//5
	 }/////////////end of main
	
	 void doStuff(Q12 p) {
		 System.out.print(" doStuff p = "+ (p.x+2));  //0
	 }////////////////end of doStuff
	 void doStuff(int x) {
		 System.out.print(" doStuff x = "+ ++this.x);  //0
	 }////////////////end of doStuff
	
}/////////////////////end of Q12
