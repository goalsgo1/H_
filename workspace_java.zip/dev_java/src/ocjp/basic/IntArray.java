package ocjp.basic;
//배열의 시작 인덱스는 항상 0 임.
//이유? a2의 주소번지와 a2[0]의 주소번지가 같기때문임.
//229540==229540  229544
//229540 229548
public class IntArray {
	void a2Print(int[] a) {
		for(int i=0;i<2;i++) {//배열의 크기가 2
		//for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);//0 1
		}
		//개선된 for문- 너가 가진거 다 보여줘
		for(int b:a) {
			System.out.println(b);
		}
	}
	public static void main(String[] args) {
		int i,j = 0;
		i=2;
		System.out.println(i+", "+j);
		int x[],y=0;
		//int[]a, b=0;
		int[]a2, b2;
		//선언시에는 대괄호를 반드시 붙이지만 생성시에는 생략함.
		//파라미터 자리에배열을 넘길 수 있다. - 연습 - 클래스 활용
		a2 = new int[2];//0 0
		b2 = new int[3];//0 0 0
		//insert here
		IntArray ia = new IntArray();
		ia.a2Print(a2);
	}

}
